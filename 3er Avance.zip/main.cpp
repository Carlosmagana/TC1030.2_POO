/*
* Bear Reserve
* Carlos Emilio Magana Arias
* A01701466
* 3er avance de proyecto
*/
#include <iostream> 
#include "Animal.h"
#include "Oso.h"
#include "Reserva.h"

using namespace std;

int main(int argc, char* argv[]){

  Reserva reserva;
  reserva.nuevo_animal();
  reserva.get_registro();
  cout<<"\n Registro de osos Kodiak:\n";
  reserva.get_registro_e("Kodiak");
}
