#ifndef AVE_H
#define AVE_H

#include <string>
#include <sstream>
#include "Animal.h"

using namespace std;

//Declaro objeto Ave que hereda de Animal
class Ave: public Animal{

    //Variables de instancia del objeto
    protected:
        string t_nido;
        string arbol;

    //Metodos del objeto
    public:

        Ave():Animal(0,"","Ave","",0,0){};
        Ave (int num, string nombre, string especie, int edad, int vida, string nido, string ar):
          Animal(num,nombre,"Ave",especie,edad,vida), t_nido(nido), arbol(ar){};

        int get_num() { return num; }
        string get_nombre() { return nombre; }
        string get_especie() { return especie; }
        int get_edad() { return edad; }
        int get_vida() { return vida; }
        string get_nido() { return t_nido; }
        string get_arbol() { return arbol; }
        virtual string caza() = 0;
        virtual bool volar() = 0;
};


//Declaro objeto Carpintero que hereda de Ave
class Carpintero: public Ave{

    private:
    	bool pico;
	//Declaro metodos publicos
    public:

        Carpintero():Ave(0,"","Pajaro carpintero",0,96,"Dentro del arbol","Abeto"){};
        Carpintero (int num, string nombre, int edad, bool pic):
          Ave(num,nombre,"Pajaro Carpintero",edad,96,"Dentro del arbol","Abeto"), pico(pic){};

        string caza();
        string come();
        int r_vida() { return vida - edad;}
        bool volar();
        string resumen();

};

string Carpintero::come(){

    string com;
	com = "Come gusanos y larvas";
	return com;
}

bool Carpintero::volar(){

    bool vol;
	if (edad<2){
    	vol = false;
	}
	else{
		vol = true;
	}
	return vol;
}

string Carpintero::caza(){
    string caz;
	if (pico==true){
        		caz="Sano";
			}
			else{
				caz="Necesita atencion medica";
			}
	return caz;
}

string Carpintero::resumen(){

    stringstream res;
    res << "ID: " << num << ", " << nombre << ", " << tipo << " " << especie << ", " 
	<< edad << " meses de " << vida << ", le quedan " << r_vida() << " meses de vida aproximadamente, Nido: " 
	<< t_nido << " en un " << arbol << ", Vuela: " << volar() << ", " << caza() << ", " << come() << "\n";
    return res.str();
}
#endif
