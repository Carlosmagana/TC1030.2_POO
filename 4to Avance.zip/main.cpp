/*
* Bear Reserve
* Carlos Emilio Magana Arias
* A01701466
* 3er avance de proyecto
*/
#include <iostream> 
#include "Animal.h"
#include "Oso.h"
#include "Ave.h"
#include "Reserva.h"

using namespace std;

int main(int argc, char* argv[]){

  Reserva reserva;
  cout<<"-----Aviso: La edad de los OSOS se toma en ANIOS enteros y la edad de las AVES en MESES-----\n\n";
  reserva.nuevo_animal();
  reserva.get_registro();
  
  cout<<"\n\n-----Es demasiada informacion, mejor hagamos unos resumenes por especie-----\n";
  cout<<"\n Registro de osos Panada:\n";
  reserva.get_registro_e("Panda");
  cout<<"\n Registro de osos Kodiak:\n";
  reserva.get_registro_e("Kodiak");
  cout<<"\n Registro de osos Negros:\n";
  reserva.get_registro_e("Negro");
  cout<<"\n Registro de Pajaros Carpinteros:\n";
  reserva.get_registro_e("Pajaro Carpintero");
  
}
