#ifndef RESERVA_H
#define RESERVA_H

#include <string>
#include <iostream>
#include <sstream>
#include "Animal.h"
#include "Oso.h"
#include "Ave.h"

using namespace std;

const int CUPO = 10000; //Cupo maximo de 10000 animales en la reserva

class Reserva {


    private:

        Animal *ani[CUPO]; 
        int id;

    public:

        Reserva(): id(0){};

        void nuevo_animal();
        void get_registro();
        void get_registro_e(string especie);

};

void Reserva::nuevo_animal(){

  ani[id] = new Kodiak(id,"Bru",9,2.1,301.4);
  id++;
  ani[id] = new Carpintero(id,"Red",5,true);
  id++;
  ani[id] = new Panda(id,"Juan",1,0.4,55);
  id++;
  ani[id] = new Kodiak(id,"Kody",24,1.7,386.7);
  id++;
  ani[id] = new Carpintero(id,"Cat",45,true);
  id++;
  ani[id] = new Carpintero(id,"Pek",90,false);
  id++;
  ani[id] = new Panda(id,"Pancho",16,1.3,167.5);
  id++;
  ani[id] = new Negro(id,"Blacky",3,1.05,123);
  id++;
  ani[id] = new Panda(id,"Hugo",7,1.3,150);
  id++;
  ani[id] = new Negro(id,"Sivi",10,1.5,204);
  id++;
  ani[id] = new Negro(id,"Dom",2,0.7,72.9);
  id++;
  ani[id] = new Kodiak(id,"Raz",3,0.9,95.2);
  id++;
  ani[id] = new Carpintero(id,"Hulio",1,false);
  id++;
  ani[id] = new Panda(id,"Oli",14,1.6,180);
  id++;
}

void Reserva::get_registro(){

	for(int i=0; i<id ;i++)
		  cout << ani[i]->resumen();
}

void Reserva::get_registro_e(string especie){
	
	int cont;
	cont = 0;
	for(int i=0; i<id ;i++){
    if(ani[i]->get_especie() == especie){
		cont++;
		cout << ani[i]->resumen();
	}
  }
  cout << "Total de " << especie << " en la reserva: " << cont << endl;
}

#endif
